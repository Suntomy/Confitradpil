#!/data/data/com.termux/files/usr/bin/bash

cd "$HOME/adegan_financial_real" || exit 1

STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP="$HOME/adegan_backups/adegan-$STAMP.tar.gz"

mkdir -p "$HOME/adegan_backups" reports

echo "=================================="
echo " ADEGAN GLOBAL CONSOLE NINJA ROBOT"
echo "=================================="

echo "[1] Creating project backup..."

tar -czf "$BACKUP" \
  --exclude='./node_modules' \
  --exclude='./.git' \
  --exclude='./.env' \
  --exclude='./.env.*' \
  --exclude='*.pem' \
  --exclude='*.key' \
  --exclude='*.keystore' \
  .

if [ $? -ne 0 ]; then
  echo "BACKUP FAILED. Stopping repairs."
  exit 1
fi

echo "Backup created: $BACKUP"

echo "[2] Checking npm dependencies..."
npm ls --depth=0 > reports/dependencies.txt 2>&1

echo "[3] Applying safe dependency security fixes..."
npm audit fix

echo "[4] Scanning JavaScript syntax..."

ERRORS=0

find . \
  -path './node_modules' -prune -o \
  -path './.git' -prune -o \
  -type f \( -name '*.js' -o -name '*.mjs' -o -name '*.cjs' \) \
  -print0 |
while IFS= read -r -d '' FILE; do
  if ! node --check "$FILE" 2>> reports/syntax-errors.txt; then
    echo "SYNTAX ERROR: $FILE"
  fi
done

echo "[5] Running automatic ESLint repairs..."

if [ -f eslint.config.js ] || \
   [ -f eslint.config.mjs ] || \
   [ -f eslint.config.cjs ] || \
   [ -f .eslintrc.json ] || \
   [ -f .eslintrc.js ] || \
   [ -f .eslintrc.cjs ]; then

  npx eslint . --fix > reports/eslint-repairs.txt 2>&1
  echo "ESLint repair completed. Check reports/eslint-repairs.txt"
else
  echo "No ESLint configuration found."
  echo "Manual configuration is required before automatic repair."
fi

echo "[6] Checking HTML files..."

find . \
  -path './node_modules' -prune -o \
  -path './.git' -prune -o \
  -type f -name '*.html' -print \
  > reports/html-files.txt

echo "HTML files found:"
cat reports/html-files.txt

echo "[7] Running available project tests..."

npm run test --if-present

echo "[8] Running final security audit..."

npm audit > reports/security-audit.txt 2>&1

echo "[9] Checking final JavaScript syntax..."

find . \
  -path './node_modules' -prune -o \
  -path './.git' -prune -o \
  -type f \( -name '*.js' -o -name '*.mjs' -o -name '*.cjs' \) \
  -print0 |
while IFS= read -r -d '' FILE; do
  node --check "$FILE" || echo "REQUIRES REPAIR: $FILE"
done

echo "=================================="
echo " ADEGAN GLOBAL SCAN COMPLETED"
echo "=================================="
echo "Backup: $BACKUP"
echo "Security report: reports/security-audit.txt"
echo "ESLint report: reports/eslint-repairs.txt"
echo "HTML list: reports/html-files.txt"
echo "Dependency report: reports/dependencies.txt"
echo "=================================="
