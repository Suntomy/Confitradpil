const Decimal = require("decimal.js");
const { getExchangeRates } = require("./exchange-rates");

async function convert(amount, from, to) {
  const value = new Decimal(amount);

  if (!value.isFinite() || value.lte(0)) {
    throw new Error("Enter a valid amount greater than zero");
  }

  from = from.toUpperCase();
  to = to.toUpperCase();

  if (!["USD", "NGN"].includes(from) ||
      !["USD", "NGN"].includes(to)) {
    throw new Error("Only USD and NGN are supported");
  }

  if (from === to) {
    return {
      amount: value.toFixed(2),
      currency: to
    };
  }

  const data = await getExchangeRates();

  if (data.base !== "USD" || !data.rates.NGN) {
    throw new Error("Valid USD/NGN exchange rate unavailable");
  }

  const rate = new Decimal(data.rates.NGN);

  const result = from === "USD"
    ? value.mul(rate)
    : value.div(rate);

  return {
    from: from,
    to: to,
    originalAmount: value.toFixed(2),
    convertedAmount: result.toDecimalPlaces(2).toFixed(2),
    exchangeRate: rate.toString(),
    updatedAt: data.timestamp,
    source: data.source,
    usingCachedData: data.usingCachedData || false
  };
}

module.exports = { convert };
