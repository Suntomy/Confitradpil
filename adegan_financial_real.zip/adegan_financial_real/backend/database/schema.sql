
CREATE TABLE IF NOT EXISTS gpb_accounts (
    id BIGSERIAL PRIMARY KEY,
    account_number CHAR(10) UNIQUE NOT NULL,
    account_name VARCHAR(200) NOT NULL,
    currency CHAR(3) NOT NULL DEFAULT 'NGN',
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CHECK (account_number ~ '^[0-9]{10}$')
);

CREATE TABLE IF NOT EXISTS gpb_transactions (
    id BIGSERIAL PRIMARY KEY,

    serial_number VARCHAR(50) UNIQUE NOT NULL,
    transaction_reference VARCHAR(80) UNIQUE NOT NULL,
    tracking_number VARCHAR(80) UNIQUE NOT NULL,
    idempotency_key VARCHAR(100) UNIQUE,

    sender_name VARCHAR(200),
    sender_account VARCHAR(100),
    sender_bank VARCHAR(200),

    recipient_name VARCHAR(200),
    recipient_account VARCHAR(100),
    recipient_bank VARCHAR(200),

    payment_provider VARCHAR(100),
    provider_reference VARCHAR(200),

    transaction_type VARCHAR(60) NOT NULL,
    amount NUMERIC(24,8) NOT NULL,
    currency CHAR(3) NOT NULL,

    transaction_fee NUMERIC(24,8) DEFAULT 0,
    description TEXT,

    transaction_status VARCHAR(30)
        NOT NULL DEFAULT 'PENDING',

    failure_reason TEXT,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    settled_at TIMESTAMPTZ,

    CHECK (amount > 0),
    CHECK (transaction_fee >= 0)
);

CREATE INDEX IF NOT EXISTS gpb_tracking_index
ON gpb_transactions(tracking_number);

CREATE INDEX IF NOT EXISTS gpb_sender_index
ON gpb_transactions(sender_account);

CREATE INDEX IF NOT EXISTS gpb_recipient_index
ON gpb_transactions(recipient_account);

CREATE INDEX IF NOT EXISTS gpb_created_index
ON gpb_transactions(created_at);

CREATE TABLE IF NOT EXISTS gpb_audit_logs (
    id BIGSERIAL PRIMARY KEY,
    action VARCHAR(100) NOT NULL,
    reference VARCHAR(100),
    details JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

