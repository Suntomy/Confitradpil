require("dotenv").config();

const express = require("express");
const session = require("express-session");
const admin = require("./routes/admin");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");

const api = require("./routes/api");

const app = express();

app.disable("x-powered-by");

app.use(helmet());

app.use(cors({
    origin: process.env.ALLOWED_ORIGINS
        ? process.env.ALLOWED_ORIGINS.split(",")
        : false
}));

app.use(express.static("public"));

app.use(express.json({
    limit: "100kb"
}));

app.use(rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 100,
    standardHeaders: "draft-7",
    legacyHeaders: false
}));

app.get("/", (req, res) => {
    res.json({
        name: "ADEGAN GLOBAL UNIVERSAL NETWORK",
        organization: "Adegan Global Enterprise",
        banking: "Global Pilgrim Bank",
        cryptocurrency: "Pilgrim Coin",
        status: "DEVELOPMENT"
    });
});

app.use(session({
  name: "adegan.admin.sid",
  secret: process.env.ADMIN_SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    maxAge: 30 * 60 * 1000
  }
}));

app.use("/api/v1/admin", admin);
app.use("/api/v1", api);

app.use((err, req, res, next) => {
    console.error("SERVER ERROR:", err.message);

    res.status(500).json({
        error: "Internal server error"
    });
});

const PORT = Number(process.env.PORT || 3000);

app.listen(PORT, "0.0.0.0", () => {
    console.log("--------------------------------");
    console.log("ADEGAN GLOBAL BACKEND");
    console.log("--------------------------------");
    console.log("Port:", PORT);
    console.log("Status: DEVELOPMENT");
    console.log("Bank: Global Pilgrim Bank");
    console.log("Coin: Pilgrim Coin");
});
