const fs = require("fs");
const path = require("path");

const file = path.join(
  __dirname,
  "../../data/recharge-inventory.json"
);

function getInventory() {
  if (!fs.existsSync(file)) return [];

  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function getAvailableCards(network) {
  return getInventory()
    .filter(card =>
      card.network === network &&
      card.status === "AVAILABLE"
    )
    .map(({ id, network, denomination, status }) => ({
      id,
      network,
      denomination,
      status
    }));
}

function redeemCard(id) {
  const inventory = getInventory();
  const card = inventory.find(item =>
    item.id === id && item.status === "AVAILABLE"
  );

  if (!card) {
    throw new Error("Recharge card unavailable");
  }

  card.status = "SOLD";

  fs.writeFileSync(file, JSON.stringify(inventory, null, 2));

  return {
    network: card.network,
    denomination: card.denomination,
    pin: card.pin
  };
}

module.exports = {
  getAvailableCards,
  redeemCard
};
