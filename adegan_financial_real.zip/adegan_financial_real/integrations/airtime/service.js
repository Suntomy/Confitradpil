const axios = require("axios");

async function buyAirtime({ network, phone, amount }) {
  if (!process.env.AIRTIME_API_URL ||
      !process.env.AIRTIME_API_KEY) {
    throw new Error("Airtime supplier API is not configured");
  }

  if (!/^234\d{10}$/.test(phone)) {
    throw new Error("Use Nigerian phone format: 234XXXXXXXXXX");
  }

  if (!Number.isFinite(amount) || amount < 50) {
    throw new Error("Invalid airtime amount");
  }

  const response = await axios.post(
    process.env.AIRTIME_API_URL,
    { network, phone, amount },
    {
      headers: {
        Authorization: `Bearer ${process.env.AIRTIME_API_KEY}`,
        "Content-Type": "application/json"
      },
      timeout: 30000
    }
  );

  return response.data;
}

module.exports = { buyAirtime };
