function checkWesternUnionConfiguration() {
  const partnerId = process.env.WU_PARTNER_ID;
  const apiKey = process.env.WU_API_KEY;

  if (!partnerId || !apiKey) {
    return {
      provider: "Western Union",
      status: "PARTNERSHIP_REQUIRED",
      operational: false
    };
  }

  return {
    provider: "Western Union",
    status: "CREDENTIALS_CONFIGURED",
    operational: false,
    message: "Partner API approval and testing are still required"
  };
}

module.exports = {
  checkWesternUnionConfiguration
};
