/*
 ADEGAN GLOBAL — GOOGLE PAY
 TEST INTEGRATION STARTER

 A real payment gateway configuration is required.
 Do not use fake gateway credentials.
*/

const GPB_GOOGLE_PAY = {
  environment: "TEST",

  apiVersion: 2,
  apiVersionMinor: 0,

  allowedPaymentMethods: [{
    type: "CARD",

    parameters: {
      allowedAuthMethods: [
        "PAN_ONLY",
        "CRYPTOGRAM_3DS"
      ],

      allowedCardNetworks: [
        "VISA",
        "MASTERCARD"
      ]
    },

    tokenizationSpecification: {
      type: "PAYMENT_GATEWAY",

      parameters: {
        gateway: "REPLACE_WITH_SUPPORTED_GATEWAY",
        gatewayMerchantId: "REPLACE_WITH_GATEWAY_MERCHANT_ID"
      }
    }
  }]
};

function loadGooglePay() {
  if (!window.google || !google.payments) {
    console.error("Google Pay library not loaded");
    return;
  }

  const paymentsClient =
    new google.payments.api.PaymentsClient({
      environment: GPB_GOOGLE_PAY.environment
    });

  const button =
    paymentsClient.createButton({
      onClick: () => {
        alert(
          "Configure your approved payment gateway before accepting payments."
        );
      }
    });

  const container =
    document.getElementById("google-pay-button");

  if (container) {
    container.appendChild(button);
  }

  console.log("GPB Google Pay test module loaded");
}

window.loadGooglePay = loadGooglePay;
