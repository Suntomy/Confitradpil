
CREATE TABLE IF NOT EXISTS adegan_accounts (
    id BIGSERIAL PRIMARY KEY,

    account_number CHAR(10) UNIQUE NOT NULL
    CHECK (account_number ~ '^[0-9]{10}$'),

    account_name VARCHAR(200) NOT NULL,

    account_type VARCHAR(50) DEFAULT 'CUSTOMER',

    currency CHAR(3) DEFAULT 'NGN',

    bank_name VARCHAR(150)
    DEFAULT 'Global Pilgrim Bank',

    status VARCHAR(30) DEFAULT 'PENDING',

    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS adegan_transactions (
    id BIGSERIAL PRIMARY KEY,

    serial_number VARCHAR(40) UNIQUE NOT NULL,

    transaction_reference VARCHAR(80) UNIQUE NOT NULL,

    tracking_number VARCHAR(80) UNIQUE NOT NULL,

    sender_account VARCHAR(10),

    sender_name VARCHAR(200),

    sender_bank VARCHAR(150),

    recipient_account VARCHAR(10),

    recipient_name VARCHAR(200),

    recipient_bank VARCHAR(150),

    payment_provider VARCHAR(80),

    provider_reference VARCHAR(150),

    transaction_type VARCHAR(50),

    amount NUMERIC(24,8) NOT NULL
    CHECK (amount > 0),

    currency CHAR(3) NOT NULL,

    transaction_fee NUMERIC(24,8) DEFAULT 0,

    description TEXT,

    payment_channel VARCHAR(80),

    country VARCHAR(100),

    transaction_status VARCHAR(30)
    DEFAULT 'PENDING',

    failure_reason TEXT,

    created_at TIMESTAMPTZ DEFAULT NOW(),

    settled_at TIMESTAMPTZ,

    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS
adegan_transaction_tracking_idx
ON adegan_transactions(tracking_number);

CREATE INDEX IF NOT EXISTS
adegan_transaction_sender_idx
ON adegan_transactions(sender_account);

CREATE INDEX IF NOT EXISTS
adegan_transaction_recipient_idx
ON adegan_transactions(recipient_account);

CREATE INDEX IF NOT EXISTS
adegan_transaction_date_idx
ON adegan_transactions(created_at);

