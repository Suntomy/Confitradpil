const { Pool } = require("pg");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

async function getBalance(accountId) {
  const result = await pool.query(
    `SELECT
       COALESCE(SUM(
         CASE
           WHEN entry_type = 'credit' THEN amount
           WHEN entry_type = 'debit' THEN -amount
         END
       ), 0)::text AS balance,
       currency
     FROM ledger_entries
     WHERE account_id = $1
     GROUP BY currency`,
    [accountId]
  );

  return result.rows;
}

module.exports = { pool, getBalance };
