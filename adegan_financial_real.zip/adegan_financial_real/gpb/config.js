module.exports = {
  bank: {
    name: "Global Pilgrim Bank Plc",
    shortName: "GPB",
    code: "GPB",
    swiftBic: null,
    country: "Nigeria",
    currency: ["NGN", "USD"],
    status: "DEVELOPMENT",
    regulatoryStatus: "CBN AUTHORISATION REQUIRED",
    slogan: "Beyond Expectations"
  },

  transaction: {
    referencePrefix: "GPB",
    supportedTypes: [
      "DEPOSIT",
      "WITHDRAWAL",
      "TRANSFER",
      "CREDIT",
      "DEBIT"
    ],
    requireProviderConfirmation: true
  }
};
