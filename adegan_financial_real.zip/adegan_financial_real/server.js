'use strict';
/**
 * Adegan Global Payments — production-capable OPay Cashier collection adapter.
 * Real incoming collection requires OPay production approval, credentials, HTTPS,
 * PostgreSQL and deployment. Outgoing payouts remain fail-closed until separately
 * approved and integrated with an authorised payout product.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Pool } = require('pg');

function loadEnv(file = path.join(__dirname, '.env')) {
  try {
    for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
    }
  } catch {}
}
loadEnv();
const PORT = Number(process.env.PORT || 3000);
const ENV = String(process.env.OPAY_ENV || 'sandbox').toLowerCase();
const LIVE = ENV === 'production';
if (!['sandbox', 'production'].includes(ENV)) throw new Error('OPAY_ENV must be sandbox or production.');
const BASE_URL = String(process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '');
const MERCHANT_ID = process.env.OPAY_MERCHANT_ID || '';
const PUBLIC_KEY = process.env.OPAY_PUBLIC_KEY || '';
const PRIVATE_KEY = process.env.OPAY_PRIVATE_KEY || '';
const DATABASE_URL = process.env.DATABASE_URL || '';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || '';
const ADMIN_PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH || '';
const CREATE_URL = LIVE
  ? 'https://liveapi.opaycheckout.com/api/v1/international/cashier/create'
  : 'https://testapi.opaycheckout.com/api/v1/international/cashier/create';
const sessions = new Map();
const limits = new Map();
const MAX_BODY = 32 * 1024;
const SESSION_MS = 8 * 60 * 60 * 1000;
const SECURE_COOKIES = process.env.NODE_ENV === 'production' || LIVE;

if (!DATABASE_URL) throw new Error('DATABASE_URL is required. Configure PostgreSQL before starting.');
const pool = new Pool({ connectionString: DATABASE_URL, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined, max: 10, idleTimeoutMillis: 30000, connectionTimeoutMillis: 10000 });

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS payment_orders (
      reference VARCHAR(80) PRIMARY KEY,
      amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
      amount_major NUMERIC(18,2) NOT NULL,
      currency CHAR(3) NOT NULL,
      customer_name VARCHAR(100) NOT NULL,
      customer_email VARCHAR(150) NOT NULL,
      customer_phone VARCHAR(20) NOT NULL,
      description VARCHAR(180) NOT NULL,
      status VARCHAR(24) NOT NULL,
      opay_order_no VARCHAR(100),
      cashier_url TEXT,
      opay_status VARCHAR(24),
      transaction_id VARCHAR(120),
      channel VARCHAR(80),
      paid_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      callback_received_at TIMESTAMPTZ,
      callback_payload JSONB,
      failure_message TEXT
    );
    CREATE UNIQUE INDEX IF NOT EXISTS payment_orders_opay_transaction_id_uq
      ON payment_orders(transaction_id) WHERE transaction_id IS NOT NULL;
    CREATE INDEX IF NOT EXISTS payment_orders_status_created_idx ON payment_orders(status, created_at DESC);
    CREATE TABLE IF NOT EXISTS audit_events (
      id BIGSERIAL PRIMARY KEY,
      event_type VARCHAR(80) NOT NULL,
      reference VARCHAR(80),
      event_data JSONB NOT NULL DEFAULT '{}'::jsonb,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}
function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin', 'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Content-Security-Policy': "default-src 'self' https: data:; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self' https:; frame-ancestors 'none'; base-uri 'self'; form-action 'self' https://*.opaycheckout.com"
  });
  res.end(body);
}
function readJson(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (Buffer.byteLength(raw) > MAX_BODY) { reject(new Error('Request body too large.')); req.destroy(); }
    });
    req.on('end', () => {
      try { resolve(raw ? JSON.parse(raw) : {}); }
      catch { reject(new Error('Request must contain valid JSON.')); }
    });
    req.on('error', reject);
  });
}
function clientIp(req) { return req.socket.remoteAddress || 'unknown'; }
function rateLimit(req, bucket, max, windowMs) {
  const key = bucket + ':' + clientIp(req), now = Date.now();
  const x = limits.get(key) || { start: now, count: 0 };
  if (now - x.start > windowMs) { x.start = now; x.count = 0; }
  x.count++; limits.set(key, x);
  if (limits.size > 5000) for (const [k, v] of limits) if (now - v.start > windowMs * 2) limits.delete(k);
  return x.count <= max;
}
function parseCookies(req) {
  const out = {};
  for (const item of String(req.headers.cookie || '').split(';')) {
    const i = item.indexOf('='); if (i > 0) out[item.slice(0, i).trim()] = decodeURIComponent(item.slice(i + 1).trim());
  }
  return out;
}
function sessionUser(req) {
  const token = parseCookies(req).ag_session;
  if (!token) return null;
  const record = sessions.get(token);
  if (!record || record.expires < Date.now()) { sessions.delete(token); return null; }
  record.expires = Date.now() + SESSION_MS;
  return record.username;
}
function requireAdmin(req, res) {
  if (!sessionUser(req)) { sendJson(res, 401, { error: 'Administrator login required.' }); return false; }
  return true;
}
function originAllowed(req) {
  const origin = req.headers.origin;
  if (!origin) return true; // Non-browser clients are still protected by authentication/rate limits.
  try { return new URL(origin).origin === new URL(BASE_URL).origin; } catch { return false; }
}
function validEmail(v) { return typeof v === 'string' && v.length <= 150 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function verifyPassword(password, encoded) {
  const [scheme, saltHex, hashHex] = String(encoded).split('$');
  if (scheme !== 'scrypt' || !/^[a-f0-9]{32,128}$/i.test(saltHex || '') || !/^[a-f0-9]{64,128}$/i.test(hashHex || '')) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length);
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}
function opayCallbackSignature(p) {
  const refunded = p.refunded === true ? 't' : 'f';
  const canonical = `{Amount:"${p.amount}",Currency:"${p.currency}",Reference:"${p.reference}",Refunded:${refunded},Status:"${p.status}",Timestamp:"${p.timestamp}",Token:"${p.token || ''}",TransactionID:"${p.transactionId}"}`;
  return crypto.createHmac('sha3-512', PRIVATE_KEY).update(canonical, 'utf8').digest('hex');
}
function safeHexEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || !/^[a-f0-9]{128}$/i.test(a) || !/^[a-f0-9]{128}$/i.test(b)) return false;
  const aa = Buffer.from(a, 'hex'), bb = Buffer.from(b, 'hex');
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function ready() { return Boolean(MERCHANT_ID && PUBLIC_KEY && PRIVATE_KEY && BASE_URL.startsWith('https://')); }
async function callback(req, res) {
  if (!PRIVATE_KEY) return sendJson(res, 503, { error: 'OPay callback verification is not configured.' });
  let body; try { body = await readJson(req); } catch (e) { return sendJson(res, 400, { error: e.message }); }
  const p = body && body.payload;
  if (!p || !p.reference || p.amount == null || !p.currency || !p.status || !p.timestamp || !p.transactionId || typeof p.refunded !== 'boolean' || !body.sha512) return sendJson(res, 400, { error: 'Invalid OPay callback payload.' });
  if (!safeHexEqual(body.sha512, opayCallbackSignature(p))) return sendJson(res, 401, { error: 'OPay callback signature verification failed.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const found = await client.query('SELECT * FROM payment_orders WHERE reference=$1 FOR UPDATE', [String(p.reference)]);
    if (!found.rowCount) { await client.query('ROLLBACK'); return sendJson(res, 404, { error: 'Unknown payment reference.' }); }
    const order = found.rows[0];
    if (String(p.currency).toUpperCase() !== order.currency.trim() || String(p.amount) !== String(order.amount_minor)) {
      await client.query("UPDATE payment_orders SET status='REVIEW', callback_received_at=NOW(), callback_payload=$2 WHERE reference=$1", [order.reference, JSON.stringify(p)]);
      await client.query("INSERT INTO audit_events(event_type,reference,event_data) VALUES('CALLBACK_MISMATCH',$1,$2)", [order.reference, JSON.stringify({ amount: String(p.amount), currency: p.currency })]);
      await client.query('COMMIT'); return sendJson(res, 409, { error: 'Payment amount or currency mismatch. Manual review required.' });
    }
    let next = order.status;
    if (p.refunded === true) next = 'REFUNDED';
    else if (p.status === 'SUCCESS') next = 'SUCCESS';
    else if (order.status !== 'SUCCESS' && order.status !== 'REFUNDED' && ['FAIL', 'CLOSE', 'CANCEL'].includes(p.status)) next = p.status;
    else if (!['SUCCESS', 'REFUNDED'].includes(order.status)) next = 'PENDING';
    await client.query(`UPDATE payment_orders SET status=$2, opay_status=$3, transaction_id=$4, channel=$5,
      paid_at=CASE WHEN $2='SUCCESS' THEN COALESCE(paid_at,$6::timestamptz) ELSE paid_at END,
      callback_received_at=NOW(), callback_payload=$7 WHERE reference=$1`,
      [order.reference, next, String(p.status), String(p.transactionId), String(p.channel || p.instrumentType || 'OPay'), p.timestamp, JSON.stringify(p)]);
    await client.query("INSERT INTO audit_events(event_type,reference,event_data) VALUES('OPAY_CALLBACK',$1,$2)", [order.reference, JSON.stringify({ status: p.status, refunded: p.refunded, transactionId: String(p.transactionId) })]);
    await client.query('COMMIT');
    return sendJson(res, 200, { received: true });
  } catch (e) {
    await client.query('ROLLBACK').catch(() => {});
    if (e.code === '23505') return sendJson(res, 409, { error: 'This OPay transaction ID is already linked to another payment reference. Manual review required.' });
    console.error('OPay callback database error:', e.message);
    return sendJson(res, 500, { error: 'Callback could not be recorded. OPay may retry.' });
  } finally { client.release(); }
}
async function createCheckout(req, res) {
  if (!rateLimit(req, 'checkout', 10, 60000)) return sendJson(res, 429, { error: 'Too many payment attempts. Please wait.' });
  if (!ready()) return sendJson(res, 503, { error: 'OPay configuration is incomplete. Set merchant ID, public/private keys and a public HTTPS URL on the server.' });
  let b; try { b = await readJson(req); } catch (e) { return sendJson(res, 400, { error: e.message }); }
  const amount = Number(b.amountNgn), name = String(b.customerName || '').trim(), email = String(b.customerEmail || '').trim(), phone = String(b.customerPhone || '').trim(), description = String(b.description || '').trim();
  if (!Number.isFinite(amount) || amount < 1 || amount > 50000000 || Math.round(amount * 100) !== amount * 100 || !name || name.length > 100 || !validEmail(email) || phone.length < 7 || phone.length > 20 || !description || description.length > 180) return sendJson(res, 400, { error: 'Enter a valid NGN amount (max two decimals), customer name, email, mobile and description.' });
  const reference = 'AG' + Date.now().toString(36).toUpperCase() + crypto.randomBytes(10).toString('hex').toUpperCase();
  const minor = Math.round(amount * 100);
  const payload = {
    country: 'NG', reference, amount: { total: minor, currency: 'NGN' },
    returnUrl: BASE_URL + '/?payment=return', callbackUrl: BASE_URL + '/api/opay/callback', cancelUrl: BASE_URL + '/?payment=cancelled',
    displayName: 'Adegan Global Enterprise', customerVisitSource: 'BROWSER', evokeOpay: true, expireAt: 30,
    userInfo: { userName: name, userEmail: email, userMobile: phone },
    product: { name: 'Adegan Global business payment', description }
  };
  await pool.query(`INSERT INTO payment_orders(reference,amount_minor,amount_major,currency,customer_name,customer_email,customer_phone,description,status)
    VALUES($1,$2,$3,'NGN',$4,$5,$6,$7,'CREATING')`, [reference, minor, amount.toFixed(2), name, email, phone, description]);
  try {
    const response = await fetch(CREATE_URL, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json', Authorization: 'Bearer ' + PUBLIC_KEY, MerchantId: MERCHANT_ID }, body: JSON.stringify(payload), signal: AbortSignal.timeout(25000) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.code !== '00000' || !data.data || !data.data.cashierUrl) {
      await pool.query("UPDATE payment_orders SET status='CREATE_FAILED',failure_message=$2 WHERE reference=$1", [reference, String(data.message || 'OPay did not accept the checkout request.').slice(0, 500)]);
      return sendJson(res, 502, { error: data.message || 'OPay checkout request failed.', providerCode: data.code || String(response.status) });
    }
    const cashier = new URL(data.data.cashierUrl);
    if (cashier.protocol !== 'https:' || !/(^|\.)opaycheckout\.com$/i.test(cashier.hostname)) throw new Error('Unexpected OPay cashier URL.');
    await pool.query("UPDATE payment_orders SET status='PENDING',opay_order_no=$2,cashier_url=$3 WHERE reference=$1", [reference, data.data.orderNo || null, cashier.toString()]);
    await pool.query("INSERT INTO audit_events(event_type,reference,event_data) VALUES('CHECKOUT_CREATED',$1,$2)", [reference, JSON.stringify({ amount: amount.toFixed(2), currency: 'NGN', environment: ENV })]);
    return sendJson(res, 200, { reference, cashierUrl: cashier.toString(), status: 'PENDING' });
  } catch (e) {
    await pool.query("UPDATE payment_orders SET status='CREATE_FAILED',failure_message=$2 WHERE reference=$1", [reference, String(e.message || 'OPay request failed').slice(0, 500)]);
    console.error('OPay checkout error:', e.message);
    return sendJson(res, 502, { error: 'Unable to create OPay checkout. Check server logs and merchant configuration.' });
  }
}
async function route(req, res) {
  const url = new URL(req.url, 'http://localhost');
  if (req.method === 'GET' && url.pathname === '/api/health') return sendJson(res, 200, {
    ok: true, service: 'Adegan OPay collection', environment: ENV,
    credentialsConfigured: Boolean(MERCHANT_ID && PUBLIC_KEY && PRIVATE_KEY), httpsConfigured: BASE_URL.startsWith('https://'),
    collectionConfigured: ready(), databaseConnected: true, payoutEnabled: false,
    notice: 'Health status does not confirm OPay production activation or settlement. Payouts require separate approval.'
  });
  if (req.method === 'POST' && url.pathname === '/api/opay/callback') return callback(req, res);
  if (req.method === 'POST' && url.pathname === '/api/admin/login') {
    if (!rateLimit(req, 'login', 8, 15 * 60 * 1000)) return sendJson(res, 429, { error: 'Too many login attempts. Try again later.' });
    let b; try { b = await readJson(req); } catch (e) { return sendJson(res, 400, { error: e.message }); }
    if (!ADMIN_USERNAME || !ADMIN_PASSWORD_HASH || typeof b.username !== 'string' || typeof b.password !== 'string' || b.username !== ADMIN_USERNAME || !verifyPassword(b.password, ADMIN_PASSWORD_HASH)) return sendJson(res, 401, { error: 'Invalid administrator credentials.' });
    const token = crypto.randomBytes(32).toString('base64url'); sessions.set(token, { username: ADMIN_USERNAME, expires: Date.now() + SESSION_MS });
    const secure = SECURE_COOKIES ? '; Secure' : '';
    res.writeHead(200, { 'Set-Cookie': `ag_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${Math.floor(SESSION_MS / 1000)}${secure}`, 'Cache-Control': 'no-store', 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, username: ADMIN_USERNAME }));
  }
  if (req.method === 'GET' && url.pathname === '/api/admin/session') return sendJson(res, 200, { authenticated: Boolean(sessionUser(req)), username: sessionUser(req) || null });
  if (req.method === 'POST' && url.pathname === '/api/admin/logout') {
    const token = parseCookies(req).ag_session; if (token) sessions.delete(token);
    res.writeHead(200, { 'Set-Cookie': 'ag_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' + (SECURE_COOKIES ? '; Secure' : ''), 'Cache-Control': 'no-store', 'Content-Type': 'application/json' });
    return res.end('{"ok":true}');
  }
  if (req.method === 'POST' && !originAllowed(req)) return sendJson(res, 403, { error: 'Request origin rejected.' });
  if (req.method === 'POST' && url.pathname === '/api/opay/checkout') return createCheckout(req, res);
  if (req.method === 'POST' && url.pathname === '/api/transfers') return sendJson(res, 501, { error: 'Outgoing transfers are disabled. OPay Cashier collection access does not authorise payouts. Obtain a separate approved payout API contract and credentials from OPay or a licensed sponsor bank before enabling transfers.' });
  if (req.method === 'GET' && url.pathname === '/api/receipts') {
    if (!requireAdmin(req, res)) return;
    const q = await pool.query("SELECT reference,amount_major::text,currency,status,paid_at,transaction_id,channel FROM payment_orders WHERE status='SUCCESS' AND opay_status='SUCCESS' ORDER BY paid_at DESC LIMIT 500");
    return sendJson(res, 200, { receipts: q.rows.map(x => ({ reference: x.reference, amountMajor: x.amount_major, currency: x.currency.trim(), status: 'VERIFIED', paidAt: x.paid_at, transactionId: x.transaction_id, channel: x.channel })) });
  }
  if (req.method === 'GET' && url.pathname.startsWith('/api/receipts/')) {
    if (!requireAdmin(req, res)) return;
    const ref = decodeURIComponent(url.pathname.slice('/api/receipts/'.length));
    const q = await pool.query("SELECT reference,amount_major::text,currency,status,paid_at,transaction_id,channel,customer_name FROM payment_orders WHERE reference=$1 AND status='SUCCESS' AND opay_status='SUCCESS'", [ref]);
    if (!q.rowCount) return sendJson(res, 404, { error: 'Verified receipt not found.' });
    const x = q.rows[0]; return sendJson(res, 200, { receipt: { reference: x.reference, amountMajor: x.amount_major, currency: x.currency.trim(), status: 'VERIFIED', paidAt: x.paid_at, transactionId: x.transaction_id, channel: x.channel, customerName: x.customer_name } });
  }
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
    const html = fs.readFileSync(path.join(__dirname, 'index.html'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': html.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'strict-origin-when-cross-origin' });
    return res.end(html);
  }
  if (req.method === 'GET' && url.pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
  return sendJson(res, 404, { error: 'Not found.' });
}
async function main() {
  await initDb();
  const server = http.createServer((req, res) => route(req, res).catch(err => { console.error('Request failed:', err.message); if (!res.headersSent) sendJson(res, 500, { error: 'Internal server error.' }); else res.end(); }));
  server.listen(PORT, () => console.log(`Adegan Payments listening on port ${PORT}; OPay ${ENV}; merchant configured=${ready()}`));
  const shutdown = async () => { server.close(); await pool.end(); process.exit(0); };
  process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
}
main().catch(err => { console.error('Startup failed:', err.message); process.exit(1); });
