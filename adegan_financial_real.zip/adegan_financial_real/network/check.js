const fs = require("fs");

const config = require("./config/networks.json");

const packages = [
  "ethers",
  "@solana/web3.js",
  "@solana/spl-token",
  "bitcoinjs-lib"
];

console.log("\nADEGAN GLOBAL NETWORK CHECK");
console.log("============================");

console.log("\nBANK:");
console.log(config.bank.name);
console.log("Status:", config.bank.status);

console.log("\nCRYPTOCURRENCY:");
console.log(config.cryptocurrency.name);
console.log("Symbol:", config.cryptocurrency.symbol);

console.log("\nBLOCKCHAIN NETWORKS:");

for (const [name, network] of Object.entries(
  config.cryptocurrency.networks
)) {
  console.log(
    name,
    "| Enabled:", network.enabled,
    "| Status:", network.status
  );
}

console.log("\nINSTALLED PACKAGES:");

for (const name of packages) {
  try {
    console.log(name, "INSTALLED:", require.resolve(name));
  } catch {
    console.log(name, "NOT INSTALLED");
  }
}

console.log("\nBridge:", config.cryptocurrency.bridge.status);
console.log("\nNetwork configuration check completed.");
