module.exports = function healthCheck(req, res) {

  res.status(200).json({
    service: "ADEGAN GLOBAL",
    status: "ONLINE",
    banking: "DEVELOPMENT",
    blockchain: "DEVELOPMENT",
    timestamp: new Date().toISOString()
  });

};
