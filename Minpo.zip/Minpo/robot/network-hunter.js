const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");
const CONFIG = path.join(ROOT, "config", "networks.json");
const LOG = path.join(ROOT, "logs", "network-hunter.log");
const REWARDS = path.join(ROOT, "network", "native-rewards.json");
const CANDIDATES = path.join(ROOT, "network", "discovered-networks.json");

function read(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

function write(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function log(message) {
  const line = new Date().toISOString() + " " + message;
  console.log(line);
  fs.appendFileSync(LOG, line + "\n");
}

async function checkNetwork(network) {
  if (!network.endpoint) {
    return {
      status: "CONFIGURATION_REQUIRED",
      checkedAt: new Date().toISOString()
    };
  }

  try {
    const options = {
      signal: AbortSignal.timeout(12000)
    };

    if (network.symbol === "ETH" ||
        network.symbol === "BNB") {
      options.method = "POST";
      options.headers = {
        "Content-Type": "application/json"
      };
      options.body = JSON.stringify({
        jsonrpc: "2.0",
        method: "eth_chainId",
        params: [],
        id: 1
      });
    }

    if (network.symbol === "SOL") {
      options.method = "POST";
      options.headers = {
        "Content-Type": "application/json"
      };
      options.body = JSON.stringify({
        jsonrpc: "2.0",
        method: "getHealth",
        params: [],
        id: 1
      });
    }

    const response = await fetch(network.endpoint, options);

    if (!response.ok) {
      throw new Error("HTTP " + response.status);
    }

    const data = await response.text();

    return {
      status: "CONNECTED",
      checkedAt: new Date().toISOString(),
      response: data.slice(0, 200)
    };

  } catch (error) {
    return {
      status: "OFFLINE",
      checkedAt: new Date().toISOString(),
      error: error.message
    };
  }
}

async function scan() {
  const config = read(CONFIG, { networks: [] });

  for (const network of config.networks) {
    const result = await checkNetwork(network);

    network.lastCheck = result;

    log(network.symbol + " : " + result.status);
  }

  write(CONFIG, config);
}

function initialise() {
  if (!fs.existsSync(REWARDS)) {
    write(REWARDS, {
      notice: "Only independently verified rewards belong here.",
      rewards: []
    });
  }

  if (!fs.existsSync(CANDIDATES)) {
    write(CANDIDATES, {
      notice: "New networks require verification and approval.",
      candidates: []
    });
  }
}

async function main() {
  initialise();

  log("MINPO NETWORK HUNTER STARTED");
  log("PGC reward conversion remains disabled until configured.");

  await scan();

  if (process.argv.includes("--once")) {
    return;
  }

  setInterval(async () => {
    try {
      await scan();
    } catch (error) {
      log("SCAN ERROR: " + error.message);
    }
  }, 60000);
}

main().catch(error => {
  log("FATAL: " + error.message);
  process.exit(1);
});
