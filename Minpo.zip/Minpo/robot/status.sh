#!/data/data/com.termux/files/usr/bin/bash
cd "$HOME/Minpo" || exit 1
echo "MINPO NETWORK ROBOT STATUS"
echo "--------------------------"
node robot/network-hunter.js --once
echo
echo "NETWORK REGISTRY:"
cat config/networks.json
echo
echo "NATIVE REWARDS:"
cat network/native-rewards.json
