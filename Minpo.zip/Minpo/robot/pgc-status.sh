#!/data/data/com.termux/files/usr/bin/bash

cd "$HOME/Minpo" || exit 1

echo "PILGRIM COIN HUMAN ROBOT"
echo "======================="

node robot/pgc-human-robot.js --once

echo
echo "PGC CONFIGURATION:"
cat pgc-network/pgc-config.json

echo
echo "ROBOT MEMORY:"
cat memory/robot-memory.json

echo
echo "DIAGNOSTIC REPORT:"
cat logs/pgc-diagnostic-report.json
