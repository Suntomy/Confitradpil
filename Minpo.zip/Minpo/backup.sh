#!/data/data/com.termux/files/usr/bin/bash
set -e
mkdir -p "$HOME/Minpo/backups" "$HOME/storage/downloads/Minpo"
NAME="MINPO-$(date +%Y%m%d-%H%M%S).tar.gz"
tar -czf "$HOME/Minpo/backups/$NAME" \
-C "$HOME/Minpo" --exclude='./backups' --exclude='./logs' .
cp "$HOME/Minpo/backups/$NAME" "$HOME/storage/downloads/Minpo/"
echo "Backup saved: $NAME"
