const axios = require("axios");

const timeout = 12000;

let snapshot = {
  application: "MINPO",
  network: "MAINNET",
  updatedAt: null,
  intervalSeconds: Number(process.env.MINPO_POLL_MS || 30000) / 1000,
  assets: {}
};

async function get(url, headers = {}) {
  const r = await axios.get(url, { timeout, headers });
  return r.data;
}

async function rpc(url, method, params = [], auth = null) {
  const config = {
    timeout,
    headers: { "Content-Type": "application/json" }
  };

  if (auth && auth.username) {
    config.auth = auth;
  }

  const r = await axios.post(url, {
    jsonrpc: "2.0",
    id: 1,
    method,
    params
  }, config);

  if (r.data.error) {
    throw new Error(r.data.error.message || "RPC error");
  }

  return r.data.result;
}

async function check(name, fn) {
  try {
    const result = await fn();

    return {
      coin: name,
      status: "LIVE",
      result,
      checkedAt: new Date().toISOString()
    };
  } catch (e) {
    return {
      coin: name,
      status: "UNAVAILABLE",
      error: e.message,
      checkedAt: new Date().toISOString()
    };
  }
}

async function refresh() {
  const jobs = {
    BTC: () => get(process.env.BTC_API + "/blocks/tip/height"),
    LTC: () => get(process.env.LTC_API + "/blocks/tip/height"),

    ETH: async () => {
      const height = await rpc(
        process.env.ETH_RPC,
        "eth_blockNumber"
      );
      return {
        blockNumber: parseInt(height, 16)
      };
    },

    SOL: async () => {
      const slot = await rpc(
        process.env.SOL_RPC,
        "getSlot",
        [{ commitment: "finalized" }]
      );
      return { finalizedSlot: slot };
    },

    BNB: async () => {
      const height = await rpc(
        process.env.BNB_RPC,
        "eth_blockNumber"
      );
      return {
        blockNumber: parseInt(height, 16)
      };
    },

    TON: async () => {
      const headers = {};
      if (process.env.TONCENTER_API_KEY) {
        headers["X-API-Key"] = process.env.TONCENTER_API_KEY;
      }

      const data = await get(
        process.env.TON_API + "/getMasterchainInfo",
        headers
      );

      if (!data.ok || !data.result) {
        throw new Error("TON API did not return valid masterchain data");
      }

      return {
        masterchainSeqno: data.result.last.seqno
      };
    }
  };

  const output = {};

  await Promise.all(
    Object.entries(jobs).map(async ([coin, fn]) => {
      output[coin] = await check(coin, fn);
    })
  );

  // DOGE requires an actual node or RPC provider.
  if (process.env.DOGE_RPC_URL) {
    output.DOGE = await check("DOGE", async () => {
      const result = await rpc(
        process.env.DOGE_RPC_URL,
        "getblockcount",
        [],
        {
          username: process.env.DOGE_RPC_USER,
          password: process.env.DOGE_RPC_PASSWORD
        }
      );
      return { blockHeight: result };
    });
  } else {
    output.DOGE = {
      coin: "DOGE",
      status: "CONFIGURATION_REQUIRED",
      message: "Add a Dogecoin mainnet RPC provider."
    };
  }

  // PGC protocol must be supplied by its actual network operator.
  if (process.env.PGC_RPC_URL && process.env.PGC_RPC_METHOD) {
    output.PGC = await check("PGC", async () => {
      let params = JSON.parse(
        process.env.PGC_RPC_PARAMS_JSON || "[]"
      );

      const result = await rpc(
        process.env.PGC_RPC_URL,
        process.env.PGC_RPC_METHOD,
        params
      );

      return { response: result };
    });
  } else {
    output.PGC = {
      coin: "PGC",
      status: "CONFIGURATION_REQUIRED",
      message: "Actual Pilgrim Coin RPC and protocol are required."
    };
  }

  output.USDT = {
    coin: "USDT",
    status: "TOKEN_NETWORKS_REQUIRED",
    message: "USDT requires its token contract and owner address on each selected network.",
    supportedNetworks: [
      "ERC20",
      "TRC20",
      "BEP20",
      "TON",
      "SOLANA"
    ]
  };

  snapshot = {
    application: "MINPO",
    network: "MAINNET",
    updatedAt: new Date().toISOString(),
    intervalSeconds: Number(process.env.MINPO_POLL_MS || 30000) / 1000,
    assets: output
  };

  return snapshot;
}

function getSnapshot() {
  return snapshot;
}

module.exports = {
  refresh,
  getSnapshot
};
