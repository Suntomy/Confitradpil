#!/data/data/com.termux/files/usr/bin/bash

set -u

ROOT="$HOME/Minpo"
cd "$ROOT" || exit 1

echo "======================================"
echo " MINPO GLOBAL NETWORK INSTALLER"
echo "======================================"

# 1. BACKUP
BACKUP="$HOME/Minpo_backup_$(date +%Y%m%d_%H%M%S)"

mkdir -p "$BACKUP"

echo "[1/9] Backing up existing project..."

tar --exclude=node_modules \
    --exclude=.git \
    -czf "$BACKUP/project.tar.gz" \
    -C "$ROOT" . 2>/dev/null

# 2. CREATE DIRECTORIES
echo "[2/9] Preparing directories..."

mkdir -p public
mkdir -p shared
mkdir -p config
mkdir -p logs
mkdir -p scripts

# 3. CENTRAL BACKEND CONFIGURATION
echo "[3/9] Creating central network configuration..."

cat > config/network.json <<'EOF'
{
  "application": "MINPO",
  "apiPrefix": "/api/minpo",
  "networkMode": "centralized-api",
  "coins": {
    "PGC": {
      "name": "Pilgrim Coin",
      "network": "PGC",
      "enabled": false
    },
    "BTC": {
      "name": "Bitcoin",
      "network": "Bitcoin",
      "enabled": false
    },
    "ETH": {
      "name": "Ethereum",
      "network": "Ethereum",
      "enabled": false
    },
    "LTC": {
      "name": "Litecoin",
      "network": "Litecoin",
      "enabled": false
    },
    "TON": {
      "name": "Toncoin",
      "network": "TON",
      "enabled": false
    },
    "USDT": {
      "name": "Tether",
      "network": "Token network",
      "enabled": false
    }
  }
}
EOF

# 4. SHARED JAVASCRIPT NETWORK ENGINE
echo "[4/9] Installing shared network engine..."

cat > shared/network.js <<'EOF'
"use strict";

const NETWORK_CONFIG = {
    apiPrefix: process.env.MINPO_API_PREFIX || "/api/minpo",
    timeout: 15000
};

async function minpoRequest(path, options = {}) {

    if (!path.startsWith("/")) {
        throw new Error("API path must begin with /");
    }

    const controller = new AbortController();

    const timeout = setTimeout(
        () => controller.abort(),
        NETWORK_CONFIG.timeout
    );

    try {

        const response = await fetch(
            NETWORK_CONFIG.apiPrefix + path,
            {
                ...options,
                signal: controller.signal,
                headers: {
                    "Accept": "application/json",
                    ...options.headers
                }
            }
        );

        if (!response.ok) {
            throw new Error(
                "MINPO API error: " + response.status
            );
        }

        return await response.json();

    } finally {
        clearTimeout(timeout);
    }
}

module.exports = {
    NETWORK_CONFIG,
    minpoRequest
};
EOF

# 5. FRONTEND NETWORK CONNECTOR
echo "[5/9] Installing browser network connector..."

cat > public/network-config.js <<'EOF'
"use strict";

window.MINPO_NETWORK = Object.freeze({

    API: "/api/minpo",

    COINS: [
        "PGC",
        "BTC",
        "ETH",
        "LTC",
        "TON",
        "USDT"
    ],

    async request(path, options = {}) {

        if (!path.startsWith("/")) {
            throw new Error("Invalid MINPO API path");
        }

        const controller = new AbortController();

        const timeout = setTimeout(
            () => controller.abort(),
            15000
        );

        try {

            const response = await fetch(
                this.API + path,
                {
                    ...options,
                    signal: controller.signal,
                    cache: "no-store",
                    headers: {
                        "Accept": "application/json",
                        ...options.headers
                    }
                }
            );

            if (!response.ok) {
                throw new Error(
                    "Network error: " + response.status
                );
            }

            return await response.json();

        } finally {
            clearTimeout(timeout);
        }
    }

});
EOF

# 6. ENVIRONMENT TEMPLATE
echo "[6/9] Creating environment template..."

if [ ! -f .env.example ]; then

cat > .env.example <<'EOF'
PORT=3100
MINPO_API_PREFIX=/api/minpo
NODE_ENV=development

# Configure actual blockchain RPC endpoints
# using trusted network providers.

PGC_RPC_URL=
BTC_RPC_URL=
ETH_RPC_URL=
LTC_RPC_URL=
TON_RPC_URL=

# USDT must use its actual token network.
USDT_NETWORK=

ENABLE_WITHDRAWALS=false
EOF

fi

# 7. CREATE NETWORK DIAGNOSTIC
echo "[7/9] Creating network diagnostic..."

cat > scripts/check-network.js <<'EOF'
"use strict";

const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");

const required = [
    "server.js",
    "package.json",
    "config/network.json",
    "shared/network.js",
    "public/network-config.js"
];

console.log("\nMINPO NETWORK DIAGNOSTICS\n");

for (const file of required) {

    const full = path.join(root, file);

    console.log(
        fs.existsSync(full)
            ? "[FOUND] " + file
            : "[MISSING] " + file
    );
}

const config = JSON.parse(
    fs.readFileSync(
        path.join(root, "config/network.json"),
        "utf8"
    )
);

console.log("\nCENTRAL API:", config.apiPrefix);

console.log("\nSUPPORTED COINS:");

for (const [symbol, coin] of Object.entries(config.coins)) {
    console.log(
        symbol + " - " +
        coin.name + " - " +
        (coin.enabled ? "ENABLED" : "NOT CONFIGURED")
    );
}

console.log("\nDiagnostic completed.");
EOF

# 8. CHECK PROJECT FILES
echo "[8/9] Inspecting project files..."

echo ""
echo "PROJECT STRUCTURE:"
find . -maxdepth 3 \
    -not -path './node_modules*' \
    -not -path './.git*' \
    -type f | sort | head -200

echo ""
echo "CHECKING API ROUTES:"

grep -RniE \
'api/minpo|wallet/balances|mining/status|rewards/history|wallet/networks' \
--include='*.js' \
--exclude-dir=node_modules \
--exclude-dir=.git \
. 2>/dev/null | head -100

# 9. COMPLETE
echo ""
echo "[9/9] Installation completed."

echo ""
echo "======================================"
echo " MINPO NETWORK INSTALLATION REPORT"
echo "======================================"

echo "Project: $ROOT"
echo "Backup: $BACKUP"
echo "Central API: /api/minpo"

echo ""
echo "Running diagnostics..."

if [ -f package.json ]; then
    node scripts/check-network.js
else
    echo "WARNING: package.json is missing."
fi

echo ""
echo "IMPORTANT:"
echo "Existing backend routes have not been overwritten."
echo "Existing mining engines have not been overwritten."
echo "Existing wallet files have not been overwritten."
echo "Existing blockchain settings have not been overwritten."
echo "Unconfigured networks remain disabled."

echo ""
echo "NEXT: Integrate the shared connector into server.js"
echo "and connect existing services to the central API."

