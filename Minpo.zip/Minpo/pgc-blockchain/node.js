const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const config = require("./config.json");
const file = path.join(__dirname, "data", "chain.json");

function sha(data) {
  return crypto.createHash("sha256")
    .update(JSON.stringify(data)).digest("hex");
}

function genesis() {
  const b = {
    index: 0,
    timestamp: 0,
    previousHash: "0".repeat(64),
    transactions: [],
    nonce: 0,
    miner: "PGC-GENESIS",
    reward: 0
  };
  b.hash = sha(b);
  return b;
}

function load() {
  if (!fs.existsSync(file)) {
    const initial = { blocks: [genesis()] };
    save(initial);
    return initial;
  }
  return JSON.parse(fs.readFileSync(file));
}

function save(data) {
  const temp = file + ".tmp";
  fs.writeFileSync(temp, JSON.stringify(data, null, 2));
  fs.renameSync(temp, file);
}

let chain = load();

function blockHash(b) {
  const copy = { ...b };
  delete copy.hash;
  return sha(copy);
}

function valid() {
  if (!chain.blocks.length) return false;
  if (chain.blocks[0].hash !== genesis().hash) return false;

  for (let i = 1; i < chain.blocks.length; i++) {
    const b = chain.blocks[i];
    const prev = chain.blocks[i - 1];

    if (b.index !== prev.index + 1) return false;
    if (b.previousHash !== prev.hash) return false;
    if (b.hash !== blockHash(b)) return false;
    if (!b.hash.startsWith("0".repeat(config.difficulty))) return false;
    if (b.reward !== config.blockReward) return false;
  }
  return true;
}

function mine(miner) {
  if (typeof miner !== "string" || !miner.trim() || miner.length > 120)
    throw new Error("Valid miner name required");

  const prev = chain.blocks[chain.blocks.length - 1];

  const b = {
    index: prev.index + 1,
    timestamp: Date.now(),
    previousHash: prev.hash,
    transactions: [],
    nonce: 0,
    miner,
    reward: config.blockReward
  };

  while (true) {
    b.hash = blockHash(b);
    if (b.hash.startsWith("0".repeat(config.difficulty))) break;
    b.nonce++;
  }

  chain.blocks.push(b);
  save(chain);
  return b;
}

function reply(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  });
  res.end(JSON.stringify(data, null, 2));
}

const server = http.createServer((req, res) => {
  if (req.method === "OPTIONS") return reply(res, 200, { ok: true });

  const url = new URL(req.url, "http://localhost");

  if (req.method === "GET" && url.pathname === "/api/health") {
    return reply(res, 200, {
      service: "MINPO PGC Blockchain",
      network: config.network,
      coin: config.coin,
      symbol: config.symbol,
      status: "RUNNING",
      blockHeight: chain.blocks.length - 1,
      consensus: config.consensus,
      mainnet: false,
      withdrawalsEnabled: false
    });
  }

  if (req.method === "GET" && url.pathname === "/api/chain")
    return reply(res, 200, chain);

  if (req.method === "GET" && url.pathname === "/api/validate")
    return reply(res, 200, {
      valid: valid(),
      height: chain.blocks.length - 1
    });

  if (req.method === "GET" && url.pathname === "/api/block/latest")
    return reply(res, 200, chain.blocks[chain.blocks.length - 1]);

  if (req.method === "POST" && url.pathname === "/api/mine") {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 5000) req.destroy();
    });
    req.on("end", () => {
      try {
        const input = JSON.parse(body || "{}");
        const b = mine(input.miner);
        reply(res, 200, {
          success: true,
          block: b,
          height: chain.blocks.length - 1,
          note: "Development reward only"
        });
      } catch (e) {
        reply(res, 400, { success: false, error: e.message });
      }
    });
    return;
  }

  reply(res, 404, { error: "Not found" });
});

server.listen(config.port, "127.0.0.1", () => {
  console.log("PGC blockchain running on port " + config.port);
});
