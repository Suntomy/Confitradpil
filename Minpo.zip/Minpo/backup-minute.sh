#!/data/data/com.termux/files/usr/bin/bash
while true; do
 bash "$HOME/Minpo/backup.sh" >> "$HOME/Minpo/logs/backup.log" 2>&1
 sleep 60
done
