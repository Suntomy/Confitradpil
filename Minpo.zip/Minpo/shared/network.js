"use strict";

const NETWORK_CONFIG = {
    apiPrefix: process.env.MINPO_API_PREFIX || "/api/minpo",
    timeout: 15000
};

async function minpoRequest(path, options = {}) {

    if (!path.startsWith("/")) {
        throw new Error("API path must begin with /");
    }

    const controller = new AbortController();

    const timeout = setTimeout(
        () => controller.abort(),
        NETWORK_CONFIG.timeout
    );

    try {

        const response = await fetch(
            NETWORK_CONFIG.apiPrefix + path,
            {
                ...options,
                signal: controller.signal,
                headers: {
                    "Accept": "application/json",
                    ...options.headers
                }
            }
        );

        if (!response.ok) {
            throw new Error(
                "MINPO API error: " + response.status
            );
        }

        return await response.json();

    } finally {
        clearTimeout(timeout);
    }
}

module.exports = {
    NETWORK_CONFIG,
    minpoRequest
};
