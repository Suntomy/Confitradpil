#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

BASE="$HOME/Minpo/integrations/production/lightning"
OUT="$BASE/backups"
mkdir -p "$OUT"
chmod 700 "$OUT"

if [ -z "${LND_REST_URL:-}" ] || [ -z "${LND_MACAROON_HEX:-}" ]; then
    echo "Set LND_REST_URL and LND_MACAROON_HEX first."
    exit 1
fi

if ! command -v openssl >/dev/null 2>&1; then
    echo "Install openssl first: pkg install openssl"
    exit 1
fi

TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT

curl --fail --silent --show-error \
    --connect-timeout 10 \
    --max-time 30 \
    -H "Grpc-Metadata-macaroon: $LND_MACAROON_HEX" \
    "$LND_REST_URL/v1/channels/backup" \
    -o "$TMP"

FILE="$OUT/channel-backup-$(date +%Y%m%d-%H%M%S).json.enc"

echo "Enter a strong backup encryption password."
openssl enc -aes-256-cbc -salt -pbkdf2 -iter 200000 \
    -in "$TMP" -out "$FILE"

chmod 600 "$FILE"

echo "Encrypted channel backup saved:"
echo "$FILE"
echo "Keep another encrypted copy in a separate secure location."
