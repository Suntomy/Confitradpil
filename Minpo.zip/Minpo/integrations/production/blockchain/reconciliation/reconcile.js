'use strict';

function normalize(tx) {
  return {
    network: String(tx.network || '').toLowerCase(),
    hash: String(tx.transaction_hash || '').toLowerCase(),
    eventIndex: String(tx.event_index ?? '0'),
    asset: String(tx.asset || '').toUpperCase(),
    amount: String(tx.amount),
    destination: String(tx.destination || '').toLowerCase()
  };
}

function reconcile(chainTransactions, ledgerTransactions) {
  const ledger = new Map();

  for (const item of ledgerTransactions) {
    const tx = normalize(item);
    const key = [
      tx.network, tx.hash, tx.eventIndex, tx.asset
    ].join(':');

    ledger.set(key, tx);
  }

  const matched = [];
  const missingFromLedger = [];
  const mismatched = [];

  for (const item of chainTransactions) {
    const tx = normalize(item);
    const key = [
      tx.network, tx.hash, tx.eventIndex, tx.asset
    ].join(':');

    const existing = ledger.get(key);

    if (!existing) {
      missingFromLedger.push(tx);
      continue;
    }

    if (
      existing.amount !== tx.amount ||
      existing.destination !== tx.destination
    ) {
      mismatched.push({ chain: tx, ledger: existing });
    } else {
      matched.push(tx);
    }

    ledger.delete(key);
  }

  return {
    matched,
    missingFromLedger,
    unmatchedLedgerEntries: [...ledger.values()],
    mismatched,
    automatic_balance_correction: false
  };
}

module.exports = { reconcile };
