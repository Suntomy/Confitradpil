'use strict';

const http = require('node:http');
const crypto = require('node:crypto');

const PORT = Number(process.env.BLOCKCHAIN_WEBHOOK_PORT || 3215);
const SECRET = process.env.BLOCKCHAIN_WEBHOOK_SECRET || '';
const seen = new Map();

function send(res, status, data) {
  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  if (req.method !== 'POST' || req.url !== '/webhooks/blockchain') {
    return send(res, 404, { error: 'Not found' });
  }

  if (!SECRET) {
    return send(res, 503, { error: 'Webhook secret not configured' });
  }

  let body = '';

  try {
    for await (const chunk of req) {
      body += chunk;
      if (body.length > 1024 * 1024) {
        return send(res, 413, { error: 'Payload too large' });
      }
    }

    const signature = req.headers['x-minpo-signature'] || '';
    const timestamp = req.headers['x-minpo-timestamp'] || '';

    if (!/^\d+$/.test(timestamp) ||
        Math.abs(Date.now() - Number(timestamp)) > 300000) {
      return send(res, 401, { error: 'Invalid timestamp' });
    }

    const expected = crypto
      .createHmac('sha256', SECRET)
      .update(timestamp + '.' + body)
      .digest('hex');

    const supplied = signature.replace(/^sha256=/, '');

    const a = Buffer.from(expected);
    const b = Buffer.from(supplied);

    if (a.length !== b.length ||
        !crypto.timingSafeEqual(a, b)) {
      return send(res, 401, { error: 'Invalid signature' });
    }

    const event = JSON.parse(body);
    const eventId = String(event.event_id || '');

    if (!eventId) {
      return send(res, 400, { error: 'event_id required' });
    }

    if (seen.has(eventId)) {
      return send(res, 200, {
        accepted: true,
        duplicate: true
      });
    }

    // Production deployment must persist this event to a
    // durable database/queue before acknowledging it.
    seen.set(eventId, Date.now());

    console.log(JSON.stringify({
      type: 'BLOCKCHAIN_EVENT_RECEIVED',
      event_id: eventId,
      network: event.network || null,
      transaction_hash: event.transaction_hash || null,
      received_at: new Date().toISOString()
    }));

    return send(res, 202, {
      accepted: true,
      event_id: eventId,
      processing: 'QUEUED_IN_MEMORY_ONLY'
    });

  } catch (error) {
    return send(res, 400, { error: error.message });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`Minpo webhook service listening on ${PORT}`);
});
