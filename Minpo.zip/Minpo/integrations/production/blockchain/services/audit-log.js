'use strict';

const fs = require('node:fs');
const path = require('node:path');

const file = path.join(__dirname, '../logs/transaction-audit.jsonl');

function record(event) {
  const safe = {
    event_type: event.event_type || 'UNKNOWN',
    network: event.network || null,
    transaction_hash: event.transaction_hash || null,
    asset: event.asset || null,
    amount: event.amount || null,
    status: event.status || null,
    timestamp: new Date().toISOString()
  };

  fs.appendFileSync(file, JSON.stringify(safe) + '\n', {
    mode: 0o600
  });
}

module.exports = { record };
