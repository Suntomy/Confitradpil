const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ledgerPath = path.join(
    process.cwd(),
    "database",
    "minpo-rewards.json"
);

let queue = Promise.resolve();

function readLedger() {

    if (!fs.existsSync(ledgerPath)) {
        return [];
    }

    return JSON.parse(
        fs.readFileSync(ledgerPath, "utf8")
    );
}

function saveLedger(records) {

    const temporary = ledgerPath + ".tmp";

    fs.writeFileSync(
        temporary,
        JSON.stringify(records, null, 2),
        { mode: 0o600 }
    );

    fs.renameSync(temporary, ledgerPath);

}

function creditReward(reward) {

    const operation = queue.then(() => {

        const records = readLedger();

        // Prevent duplicate reward credits.
        if (
            records.some(
                item => item.eventId === reward.eventId
            )
        ) {
            return {
                success: false,
                duplicate: true,
                message: "Reward already recorded"
            };
        }

        const amount = Number(reward.amount);

        if (
            !Number.isFinite(amount) ||
            amount <= 0 ||
            amount > 1000000000
        ) {
            throw new Error("Invalid reward amount");
        }

        const record = {
            id: crypto.randomUUID(),
            eventId: reward.eventId,
            coin: reward.coin,
            amount,
            source: reward.source,
            blockHash: reward.blockHash,
            transactionHash: reward.transactionHash || null,
            confirmations: reward.confirmations,
            status: "CONFIRMED",
            creditedAt: new Date().toISOString()
        };

        records.push(record);

        saveLedger(records);

        return {
            success: true,
            reward: record
        };

    });

    queue = operation.catch(() => {});

    return operation;
}

function getBalances() {

    const records = readLedger();

    const balances = {};

    for (const record of records) {

        if (record.status !== "CONFIRMED") continue;

        balances[record.coin] =
            (balances[record.coin] || 0) +
            Number(record.amount);
    }

    return balances;
}

function getHistory() {
    return readLedger();
}

module.exports = {
    creditReward,
    getBalances,
    getHistory
};
