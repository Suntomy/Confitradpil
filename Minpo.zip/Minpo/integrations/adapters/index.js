const path = require("path");

const COINS = ["PGC", "BTC", "ETH", "LTC", "TON", "USDT"];

const ENV_PATHS = {
    PGC: "PGC_ADAPTER",
    BTC: "BTC_ADAPTER",
    ETH: "ETH_ADAPTER",
    LTC: "LTC_ADAPTER",
    TON: "TON_ADAPTER",
    USDT: "USDT_ADAPTER"
};

const adapters = {};

for (const coin of COINS) {
    const configuredPath = process.env[ENV_PATHS[coin]];

    if (!configuredPath) {
        adapters[coin] = null;
        continue;
    }

    try {
        const absolutePath = path.resolve(
            process.cwd(),
            configuredPath
        );

        adapters[coin] = require(absolutePath);

    } catch (error) {
        console.error(
            `[MINPO] ${coin} adapter unavailable:`,
            error.message
        );

        adapters[coin] = null;
    }
}

module.exports = {
    COINS,
    adapters
};
