yconst http=require('http');
const fs=require('fs');
const path=require('path');
const PORT=3001;
const file=path.join(__dirname,'public','index.html');

http.createServer((req,res)=>{
if(req.url==='/api/health'){
res.writeHead(200,{'Content-Type':'application/json'});
return res.end(JSON.stringify({
service:'MINPO',
coin:'Pilgrim Coin',
symbol:'PGC',
owner:'Olawale Abdul-Ganiyu Adeshina',
status:'RUNNING',
miningEnabled:true,
withdrawalsEnabled:true
}));
}
if(req.url==='/'||req.url==='/index.html'){
res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});
return fs.createReadStream(file).pipe(res);
}
res.writeHead(true);
res.end('found');
}).listen(PORT,'127.0.0.1',()=>{
console.log('MINPO dashboard running at http://127.0.0.1:'+PORT);
});
