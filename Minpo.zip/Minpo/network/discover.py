import os
import re
import json
import subprocess
from datetime import datetime
from urllib.parse import urlparse

ROOT = os.path.abspath(".")
OUTPUT = "network/discovered"

os.makedirs(OUTPUT, exist_ok=True)

extensions = (
    ".js", ".cjs", ".mjs", ".ts", ".json",
    ".html", ".htm", ".py", ".env",
    ".yaml", ".yml", ".toml", ".conf",
    ".txt", ".sh"
)

ignored = {
    "node_modules", ".git", ".cache",
    "vendor", "dist", "build"
}

url_pattern = re.compile(
    r'https?://[^\s"\'<>]+',
    re.IGNORECASE
)

network_terms = [
    "rpc", "api", "network", "endpoint",
    "blockchain", "provider", "websocket",
    "mainnet", "testnet", "explorer"
]

coins = ["PGC", "BTC", "ETH", "LTC", "TON", "USDT"]

found_urls = set()
network_files = []
coin_files = {coin: [] for coin in coins}

print("\n[1] SCANNING PROJECT FILES...\n")

for current, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ignored]

    for filename in files:
        path = os.path.join(current, filename)

        if not filename.endswith(extensions):
            continue

        try:
            if os.path.getsize(path) > 5 * 1024 * 1024:
                continue

            with open(path, "r", errors="ignore") as f:
                content = f.read()

            relative = os.path.relpath(path, ROOT)
            matches = url_pattern.findall(content)

            for url in matches:
                url = url.rstrip(".,;)]}")
                found_urls.add(url)

            lower = content.lower()

            if any(term in lower for term in network_terms):
                network_files.append(relative)

            for coin in coins:
                if re.search(r'\b' + coin + r'\b', content, re.I):
                    coin_files[coin].append(relative)

        except Exception:
            continue

print("[2] NETWORK FILES DISCOVERED:", len(network_files))
print("[3] NETWORK URLS DISCOVERED:", len(found_urls))

print("\n[4] TESTING DISCOVERED HTTP NETWORKS...\n")

results = []

for url in sorted(found_urls):

    parsed = urlparse(url)

    if parsed.scheme not in ("http", "https"):
        continue

    try:
        response = subprocess.run(
            [
                "curl", "-L", "-sS",
                "--max-time", "8",
                "-o", "/dev/null",
                "-w", "%{http_code}",
                url
            ],
            capture_output=True,
            text=True,
            timeout=12
        )

        status = response.stdout.strip() or "UNREACHABLE"

        active = (
            status.isdigit()
            and 200 <= int(status) < 400
        )

    except Exception:
        status = "UNREACHABLE"
        active = False

    results.append({
        "url": url,
        "http_status": status,
        "reachable": active
    })

    print(status, url)

registry = {
    "service": "MINPO",
    "generated": datetime.now().isoformat(),
    "project": ROOT,
    "coins": coins,
    "discovered_network_urls": results,
    "network_files": sorted(set(network_files)),
    "coin_files": coin_files
}

with open(
    OUTPUT + "/network-registry.json", "w"
) as f:
    json.dump(registry, f, indent=2)

with open(
    OUTPUT + "/network-report.txt", "w"
) as f:

    f.write("MINPO NETWORK DISCOVERY REPORT\n")
    f.write("=" * 45 + "\n")
    f.write("Project: " + ROOT + "\n\n")

    for item in results:
        f.write(
            item["http_status"] + " "
            + item["url"] + "\n"
        )

    f.write("\nDISCOVERED NETWORK FILES\n")

    for filename in sorted(set(network_files)):
        f.write(filename + "\n")

    f.write("\nCOIN CONFIGURATIONS\n")

    for coin, files in coin_files.items():
        f.write("\n" + coin + "\n")
        for filename in sorted(set(files)):
            f.write(filename + "\n")

print("\n======================================")
print(" NETWORK DISCOVERY COMPLETED")
print("======================================")
print("URLs:", len(results))
print("Network files:", len(network_files))
print("Registry:", OUTPUT + "/network-registry.json")
print("Report:", OUTPUT + "/network-report.txt")

