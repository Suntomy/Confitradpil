# Pilgrim Universal Broker Connection

Each broker requires its own verified adapter.

Required adapter operations:
- connect()
- getAccount()
- getPositions()
- getHistory()
- placeOrder()
- closePosition()
- disconnect()

Before enabling an adapter, verify:
1. Official broker API documentation and permission.
2. Secure user authentication and account ownership.
3. Live account identity and read-only account data.
4. Order execution and close-position confirmation.
5. Idempotency and duplicate-order protection.
6. Audit records and reconciliation.
7. Rate limits, error handling and token expiry.

Never request or store a broker account password in website JavaScript.
Use encrypted server-side credentials or the broker's supported
authorization flow.

No adapter is live merely because it is registered.
All order execution remains disabled until separately approved.
