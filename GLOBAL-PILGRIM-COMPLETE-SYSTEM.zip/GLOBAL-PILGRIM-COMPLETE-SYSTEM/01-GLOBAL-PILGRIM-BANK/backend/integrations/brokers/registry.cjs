'use strict';

const adapters = new Map();

function registerBroker(name, adapter) {
  if (!name || !adapter) {
    throw new Error('Broker name and adapter are required');
  }

  if (adapters.has(name)) {
    throw new Error('Broker already registered');
  }

  adapters.set(name, adapter);
}

function getBroker(name) {
  return adapters.get(name) || null;
}

function listBrokers() {
  return [...adapters.keys()];
}

module.exports = {
  registerBroker,
  getBroker,
  listBrokers
};
