require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3100);
const HOST = process.env.HOST || "127.0.0.1";

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(cors({ origin: false }));
app.use(express.json({ limit: "20kb" }));

const FLW = "https://api.flutterwave.com/v3";

function providerReady() {
  return Boolean(process.env.FLW_SECRET_KEY);
}

async function flwRequest(endpoint, options = {}) {
  if (!providerReady()) {
    const error = new Error("Flutterwave credentials are not configured.");
    error.status = 503;
    throw error;
  }

  const response = await fetch(FLW + endpoint, {
    ...options,
    headers: {
      Authorization: `Bearer ${process.env.FLW_SECRET_KEY}`,
      "Content-Type": "application/json",
      Accept: "application/json",
      ...(options.headers || {})
    },
    signal: AbortSignal.timeout(15000)
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(data.message || "Payment provider request failed.");
    error.status = response.status;
    throw error;
  }

  return data;
}

app.get("/api/health", (req, res) => {
  res.json({
    service: "Pilgrim Real Services",
    status: "online",
    simulatedData: false,
    providerConfigured: providerReady(),
    bankVerification: providerReady() ? "available" : "not_configured",
    brokerConnection: "not_connected",
    orderExecution: false,
    payoutsEnabled: false,
    timestamp: new Date().toISOString()
  });
});

app.get("/api/ng/banks", async (req, res) => {
  try {
    const result = await flwRequest("/banks/NG");
    res.json({
      source: "Flutterwave",
      liveProviderResponse: true,
      banks: result.data || []
    });
  } catch (error) {
    res.status(error.status || 502).json({
      error: error.message,
      banks: [],
      liveProviderResponse: false
    });
  }
});

app.post("/api/ng/resolve", async (req, res) => {
  try {
    const { bankCode, accountNumber } = req.body || {};

    if (!/^[0-9]{3,10}$/.test(String(bankCode || ""))) {
      return res.status(400).json({ error: "Invalid bank code." });
    }

    if (!/^[0-9]{10}$/.test(String(accountNumber || ""))) {
      return res.status(400).json({ error: "Enter a valid 10-digit account number." });
    }

    const result = await flwRequest("/accounts/resolve", {
      method: "POST",
      body: JSON.stringify({
        account_bank: String(bankCode),
        account_number: String(accountNumber)
      })
    });

    res.json({
      verified: result.status === "success",
      accountName: result.data?.account_name || null,
      accountNumber: result.data?.account_number || null,
      provider: "Flutterwave"
    });
  } catch (error) {
    res.status(error.status || 502).json({
      verified: false,
      error: error.message
    });
  }
});

/*
 * Intentionally no transfer execution here.
 *
 * A real withdrawal requires:
 * - authenticated user and admin authorization
 * - a persistent, auditable wallet ledger
 * - verified source-of-funds and available balance
 * - idempotency and duplicate-payment protection
 * - provider approval and enabled live transfers
 * - beneficiary verification
 * - webhook signature verification
 * - transfer-status reconciliation
 *
 * Do not replace this lock with a simple environment toggle.
 */
app.post("/api/ng/withdraw", (req, res) => {
  res.status(423).json({
    status: "locked",
    message: "Withdrawals are not enabled. A verified wallet ledger, user authentication, payout approval and provider reconciliation are required.",
    moneyMoved: false
  });
});

app.get("/api/brokers", (req, res) => {
  res.json({
    HFM: {
      connected: false,
      liveData: false,
      message: "Requires supported authenticated MT5 connection."
    },
    PUPRIME: {
      connected: false,
      liveData: false,
      message: "Requires supported authenticated MT5 connection."
    }
  });
});

app.get("/api/ng/withdraw/status", (req, res) => {
  res.json({
    status: "locked",
    providerConfigured: providerReady(),
    payoutsEnabled: false,
    message: "No payout has been initiated."
  });
});

app.use(express.static(path.join(__dirname, "public")));

app.use((err, req, res, next) => {
  console.error(new Date().toISOString(), err.message);
  res.status(500).json({ error: "Internal service error." });
});

app.listen(PORT, HOST, () => {
  console.log(`Pilgrim Real Services listening on http://${HOST}:${PORT}`);
});
