const fs = require("fs");

const config = JSON.parse(
  fs.readFileSync("config/testnet.json", "utf8")
);

const logFile = "robot/logs/monitor.log";

async function check() {
  for (const [coin, network] of Object.entries(config.networks)) {
    let status;

    if (!network.enabled) {
      status = "DISABLED";
    } else if (!network.rpc) {
      status = "PROVIDER REQUIRED";
    } else {
      try {
        const response = await fetch(network.rpc, {
          signal: AbortSignal.timeout(5000)
        });
        status = "ENDPOINT RESPONDED: HTTP " + response.status;
      } catch {
        status = "CONNECTION UNAVAILABLE";
      }
    }

    const line = new Date().toISOString() +
      " | " + coin + " | " + status;

    fs.appendFileSync(logFile, line + "\n");
    console.log(line);
  }
}

console.log("GLOBAL PILGRIM MONITOR TEST");
check().catch(console.error);
