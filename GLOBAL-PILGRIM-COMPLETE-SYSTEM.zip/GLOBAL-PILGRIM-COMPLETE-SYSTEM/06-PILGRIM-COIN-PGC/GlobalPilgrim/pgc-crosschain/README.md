# PilgrimCoin Cross-Chain Development

This directory contains the initial PGC token contract,
network configuration, independent blockchain specification,
wallet integration notes and bridge development status.

Current status: DEVELOPMENT ONLY.

The token contract requires compilation, a chosen initial supply,
deployment, verification and testing.

The independent blockchain and cross-chain bridge are not live.
