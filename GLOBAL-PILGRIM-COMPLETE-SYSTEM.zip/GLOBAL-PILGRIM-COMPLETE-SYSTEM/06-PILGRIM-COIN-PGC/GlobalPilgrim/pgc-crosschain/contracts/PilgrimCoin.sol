// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/*
 * PilgrimCoin (PGC)
 * Fixed supply is selected at deployment.
 * This contract does not create a bridge or exchange.
 */
contract PilgrimCoin is ERC20 {
    constructor(uint256 initialSupply)
        ERC20("PilgrimCoin", "PGC")
    {
        _mint(msg.sender, initialSupply);
    }
}
