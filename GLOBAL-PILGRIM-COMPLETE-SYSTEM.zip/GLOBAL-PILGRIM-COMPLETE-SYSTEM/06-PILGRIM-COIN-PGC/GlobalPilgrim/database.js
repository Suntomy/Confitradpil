const fs = require("fs");
const path = require("path");

const directory = path.join(__dirname, "database");

fs.mkdirSync(directory, { recursive: true });

const logFile = path.join(directory, "audit.jsonl");

function audit(event) {
    const record = {
        timestamp: new Date().toISOString(),
        ...event
    };

    fs.appendFileSync(
        logFile,
        JSON.stringify(record) + "\n",
        { mode: 0o600 }
    );

    return record;
}

module.exports = { audit };
