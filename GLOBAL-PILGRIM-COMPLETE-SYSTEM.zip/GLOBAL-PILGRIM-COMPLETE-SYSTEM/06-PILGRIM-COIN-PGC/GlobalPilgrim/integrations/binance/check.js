const https = require("https");

function get(url) {
  return new Promise((resolve, reject) => {
    https.get(url, response => {
      let data = "";
      response.on("data", chunk => data += chunk);
      response.on("end", () => {
        if (response.statusCode >= 200 &&
            response.statusCode < 300) {
          resolve(data);
        } else {
          reject(new Error("HTTP " + response.statusCode));
        }
      });
    }).on("error", reject);
  });
}

async function rpc(url, method) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method,
      params: []
    })
  });

  if (!response.ok) {
    throw new Error("RPC HTTP " + response.status);
  }

  const result = await response.json();

  if (result.error) {
    throw new Error(JSON.stringify(result.error));
  }

  return result.result;
}

async function main() {
  console.log("\nGLOBAL PILGRIM LIVE CONNECTIVITY CHECK\n");

  try {
    const result = JSON.parse(
      await get("https://api.binance.com/api/v3/ping")
    );
    console.log("Binance public API: CONNECTED");
    console.log("Response:", JSON.stringify(result));
  } catch (error) {
    console.log("Binance API: NOT CONNECTED -", error.message);
  }

  try {
    const chain = await rpc(
      "https://bsc-dataseed.binance.org",
      "eth_chainId"
    );

    if (parseInt(chain, 16) !== 56) {
      throw new Error("Unexpected network chain ID");
    }

    const block = await rpc(
      "https://bsc-dataseed.binance.org",
      "eth_blockNumber"
    );

    console.log("BNB Smart Chain: CONNECTED");
    console.log("Chain ID:", parseInt(chain, 16));
    console.log("Latest block:", parseInt(block, 16));
  } catch (error) {
    console.log("BNB Smart Chain: NOT CONNECTED -", error.message);
  }

  console.log("\nConnectivity checks completed.");
  console.log("No funds were transferred.");
  console.log("No withdrawals were enabled.");
}

main();
