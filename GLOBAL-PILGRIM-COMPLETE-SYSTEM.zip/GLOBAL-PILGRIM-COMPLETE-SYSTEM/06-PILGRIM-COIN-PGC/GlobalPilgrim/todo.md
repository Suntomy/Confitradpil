# Pilgrim Mining App — Build Plan

## Build
- [x] Create single-file index.html (mining dashboard + wallet + withdraw + history)
- [x] Add 7 coins: Pilgrimcoin (main) + Bitcoin + Ethereum + Litecoin + Dogecoin + Monero + Ravencoin
- [x] Mining engine with live balances, hash rate, start/stop, 300-coin goal cap
- [x] Wallet: per-coin balance, wallet address, mining/withdraw address, Pilgrim main wallet
- [x] Send/Withdraw: coin + wallet address + amount -> moves mining balance to wallet, logs history
- [x] History table + balance tracking
- [x] localStorage persistence + reset + backup download
- [x] Package as zip for local download

## Deliver
- [x] Attach index.html and zip
