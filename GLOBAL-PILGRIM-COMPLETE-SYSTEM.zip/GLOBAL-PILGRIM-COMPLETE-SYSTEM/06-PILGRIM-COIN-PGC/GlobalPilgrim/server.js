require("dotenv").config();

const express = require("express");
const { JsonRpcProvider } = require("ethers");

const app = express();

app.use(express.json({ limit: "32kb" }));

app.get("/api/health", (req, res) => {
    res.json({
        service: "Global Pilgrim",
        status: "RUNNING",
        realMoneyEnabled:
            process.env.REAL_MONEY_ENABLED === "true",
        withdrawalsEnabled:
            process.env.WITHDRAWALS_ENABLED === "true",
        timestamp: new Date().toISOString()
    });
});

app.get("/api/network", async (req, res) => {
    try {
        if (!process.env.RPC_URL) {
            return res.status(503).json({
                connected: false,
                error: "RPC_URL not configured"
            });
        }

        const provider =
            new JsonRpcProvider(process.env.RPC_URL);

        const network = await provider.getNetwork();
        const block = await provider.getBlockNumber();

        res.json({
            connected: true,
            chainId: network.chainId.toString(),
            blockNumber: block
        });

    } catch (error) {
        res.status(503).json({
            connected: false,
            error: error.message
        });
    }
});

app.get("/api/security", (req, res) => {
    res.json({
        privateKeysExposed: false,
        realMoneyEnabled:
            process.env.REAL_MONEY_ENABLED === "true",
        withdrawalsEnabled:
            process.env.WITHDRAWALS_ENABLED === "true",
        productionStatus: "NOT YET APPROVED"
    });
});

app.use((req, res) => {
    res.status(404).json({
        error: "API route not found"
    });
});

const port = Number(process.env.PORT || 3000);

app.listen(port, "127.0.0.1", () => {
    console.log(
        `GLOBAL PILGRIM SERVER RUNNING ON ${port}`
    );
});
