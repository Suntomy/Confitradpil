const { createWallet, signMessage } = require("../wallet");

module.exports = {
    createWallet,
    signMessage
};
