async function withdraw() {
    if (process.env.REAL_MONEY_ENABLED !== "true") {
        throw new Error("Real-money withdrawals are disabled");
    }

    if (process.env.WITHDRAWALS_ENABLED !== "true") {
        throw new Error("Withdrawals are disabled");
    }

    throw new Error(
        "Production signing and withdrawal authorization " +
        "must be configured before withdrawals can operate."
    );
}

module.exports = { withdraw };
