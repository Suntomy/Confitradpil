const { JsonRpcProvider, getAddress } = require("ethers");

async function verifyDeposit({
    rpcUrl,
    txHash,
    expectedAddress,
    expectedChainId
}) {
    if (!rpcUrl || !txHash || !expectedAddress) {
        throw new Error("Missing deposit verification parameters");
    }

    const provider = new JsonRpcProvider(rpcUrl);

    const network = await provider.getNetwork();

    if (
        expectedChainId &&
        network.chainId !== BigInt(expectedChainId)
    ) {
        throw new Error("Unexpected blockchain network");
    }

    const receipt = await provider.getTransactionReceipt(txHash);

    if (!receipt) {
        return {
            confirmed: false,
            status: "PENDING"
        };
    }

    if (receipt.status !== 1) {
        return {
            confirmed: false,
            status: "FAILED"
        };
    }

    const tx = await provider.getTransaction(txHash);

    if (!tx) {
        throw new Error("Transaction not found");
    }

    if (tx.to?.toLowerCase() !==
        getAddress(expectedAddress).toLowerCase()) {
        throw new Error("Deposit destination mismatch");
    }

    return {
        confirmed: true,
        status: "CONFIRMED",
        transactionHash: txHash,
        blockNumber: receipt.blockNumber,
        confirmations:
            await receipt.confirmations(),
        amountWei: tx.value.toString(),
        destination: tx.to
    };
}

module.exports = { verifyDeposit };
