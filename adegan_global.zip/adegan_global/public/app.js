const $ = (id) => document.getElementById(id);
const api = async (path, options = {}) => {
  const response = await fetch(`/api${path}`, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
};
function message(id, text, kind = "") {
  const el = $(id); el.textContent = text; el.className = `message ${kind}`;
}
function showDashboard(user) {
  $("authScreen").classList.add("hidden");
  $("dashboard").classList.remove("hidden");
  $("customerName").textContent = user.fullName;
  $("cardName").textContent = user.fullName.toUpperCase().slice(0, 22);
  $("accountNumber").textContent = user.accountNumber;
  $("accountEmail").textContent = user.email;
  $("accountStatus").textContent = user.status;
  refreshDashboard();
}
async function refreshDashboard() {
  try {
    const data = await api("/me");
    $("balance").textContent = new Intl.NumberFormat("en-NG", {style:"currency",currency:"NGN"}).format(data.account.balanceKobo / 100);
    $("customerName").textContent = data.user.fullName;
    $("cardName").textContent = data.user.fullName.toUpperCase().slice(0, 22);
    $("accountNumber").textContent = data.account.accountNumber;
    $("accountStatus").textContent = data.user.status;
    $("accountEmail").textContent = data.user.email;
    const rows = $("transactions");
    rows.innerHTML = "";
    if (!data.transactions.length) {
      rows.innerHTML = '<tr><td colspan="6">No transactions yet.</td></tr>';
    } else {
      for (const tx of data.transactions) {
        const tr = document.createElement("tr");
        const vals = [new Date(tx.createdAt).toLocaleString(), tx.reference, tx.description, tx.type, `${tx.type === "credit" ? "+" : "−"}${(tx.amountKobo/100).toLocaleString("en-NG",{style:"currency",currency:"NGN"})}`, tx.status];
        vals.forEach(v => { const td=document.createElement("td"); td.textContent=v; tr.appendChild(td); });
        rows.appendChild(tr);
      }
    }
  } catch (e) { message("transferMessage", e.message, "error"); }
}
async function checkHealth() {
  try {
    const h = await fetch("/api/health");
    if (!h.ok) throw new Error();
    $("netDot").style.background = "#36c58a";
    $("netLabel").textContent = "Service online";
  } catch {
    $("netDot").style.background = "#e2b451";
    $("netLabel").textContent = "Server not connected";
  }
}
document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b === btn));
  $("loginForm").classList.toggle("hidden", btn.dataset.tab !== "login");
  $("registerForm").classList.toggle("hidden", btn.dataset.tab !== "register");
  message("authMessage", "");
}));
$("loginForm").addEventListener("submit", async e => {
  e.preventDefault(); message("authMessage", "Signing in…");
  try {
    const result = await api("/auth/login", {method:"POST",body:JSON.stringify({email:$("loginEmail").value,password:$("loginPassword").value})});
    showDashboard(result.user);
  } catch(err) { message("authMessage", err.message, "error"); }
});
$("registerForm").addEventListener("submit", async e => {
  e.preventDefault(); message("authMessage", "Creating account…");
  try {
    const result = await api("/auth/register", {method:"POST",body:JSON.stringify({fullName:$("regName").value,email:$("regEmail").value,phone:$("regPhone").value,password:$("regPassword").value})});
    showDashboard(result.user);
  } catch(err) { message("authMessage", err.message, "error"); }
});
$("logoutBtn").addEventListener("click", async () => {
  try { await api("/auth/logout",{method:"POST"}); } finally {
    $("dashboard").classList.add("hidden"); $("authScreen").classList.remove("hidden");
  }
});
$("transferForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!confirm(`Send ₦${Number($("transferAmount").value).toLocaleString()} to account ${$("toAccount").value}?`)) return;
  message("transferMessage","Processing transfer…");
  try {
    const result = await api("/transfers/internal",{method:"POST",body:JSON.stringify({toAccount:$("toAccount").value,amountNaira:$("transferAmount").value,memo:$("transferMemo").value})});
    message("transferMessage",`Transfer successful. Reference: ${result.reference}`,"success");
    e.target.reset(); await refreshDashboard();
  } catch(err) { message("transferMessage",err.message,"error"); }
});
$("depositForm").addEventListener("submit", async e => {
  e.preventDefault(); message("depositMessage","Connecting to payment provider…");
  try {
    const result = await api("/payments/initialize",{method:"POST",body:JSON.stringify({amountNaira:$("depositAmount").value})});
    if (!result.authorizationUrl) throw new Error("Payment provider did not return a checkout link.");
    window.location.href = result.authorizationUrl;
  } catch(err) { message("depositMessage",err.message,"error"); }
});
$("refreshBtn").addEventListener("click",refreshDashboard);
$("year").textContent = new Date().getFullYear();
checkHealth();
(async () => {
  try { const data = await api("/me"); showDashboard(data.user); }
  catch { /* signed-out visitor */ }
})();
