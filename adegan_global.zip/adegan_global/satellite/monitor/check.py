import socket
import json
import time
from datetime import datetime

HOSTS = [
    ("Google DNS", "8.8.8.8"),
    ("Cloudflare DNS", "1.1.1.1")
]

while True:
    results = []

    for name, host in HOSTS:
        try:
            start = time.time()
            socket.create_connection((host, 53), timeout=5).close()
            latency = round((time.time() - start) * 1000, 2)
            status = "ONLINE"
        except Exception:
            latency = None
            status = "OFFLINE"

        results.append({
            "service": name,
            "status": status,
            "latency_ms": latency
        })

    report = {
        "network": "ADEGAN GLOBAL SATELLITE NETWORK",
        "time": datetime.now().isoformat(),
        "connections": results
    }

    with open("satellite/logs/network.json", "a") as f:
        f.write(json.dumps(report) + "\n")

    print(json.dumps(report, indent=2))
    time.sleep(60)
